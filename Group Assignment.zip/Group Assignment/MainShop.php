<?php 

	session_start();
?>
<html>
	<head>

		<title> Group Assignment - Troy Fitzgerald (C16432792) & Khurram Farooq (C16364286) </title>
		
		<link id = "css" rel="stylesheet" type="text/css" href="assign.css">
		
	</head>
	<body>
	<div id = "whole">

		<div id = "main">

			<div id = "navbar">
			<ul>
				<li><div id = "logoimg"><img id = "logo" src= "images/assignlogo.png" height = "70px" width="80px" onclick="window.location.href = 'WebDAssign.php'" /></div></li>
				<li><input id="shopbutton" type="button" value="Shop" onclick="window.location.href = 'MainShop.php'" /></li>		
				<li><input id="cartbutton" type="button" value="Cart" onclick="window.location.href = 'Cart.php'" /></li>
				<li><input id="wishlistbutton" type="button" value="Wish List" onclick="window.location.href = 'WishList.php'" /></li>
				
				 <?php
				
				
				if (isset($_SESSION['username'])) {
				echo "<li><input id='loginbutton' type='button' value='Account' onclick='window.location.href =\"Account.php\"' /></li>";
				echo "<li><input id='loginbutton' type='button' value='Log Out' onclick='window.location.href =\"logout.php\"' /></li>";
				}
				else
				{
				?>	
				<li><input id="loginbutton" type="button" value="Login" onclick="window.location.href = 'Login.php'" /></li>
				<li><input id="registerbutton" type="button" value="Register" onclick="window.location.href = 'Register.php'" /></li>
			</ul>
				<?php }
				?>
		</div>
			
			<div id = "filterbar">
			
					<ul>
					<form id = "filter" action="Mainshop.php" method="post">
						<li><input id="topsbutton" type="submit" value="Tops" name ="Tops" /></li>
						<li><input id="bottomsbutton" type="submit" value="Bottoms" name = "Bottoms" /></li>	
						<li><input id="footwearbutton" type="submit" value="Footwear" name = "Footwear" /></li>		
						<li><input id="accessoriesbutton" type="submit" value="Accessories" name = "Accessories" /></li>
					</form>
					</ul>
			</div>
			
			<div id = "searchbar">
			
				<form id = "searchform" action="Mainshop.php" method="post">
					<input id = "search" type="text" name = "search" placeholder = "Search Here" />
				</form>
			</div>
			
			
			<div id = "items">
				
						<?php 
						if(isset($_POST['search']))   //Displays Images and Details of items on page
						{
							$search = $_POST['search'];
							
							for( $id = 0; $id<1; $id++)
							{
							
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								$sql  = "SELECT * FROM clothes where `Type` LIKE '$search' OR `Description` LIKE '$search'";
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									$image = $rows['Picture'];
									
									echo '<div id = "holderrows">';
										echo '<div id = "holder">';

											echo "<img src='$image' width= '200px' height='300px' >";
											echo "<p id='Desc'>".$rows['Description']."</p>";
									
											echo "<form id='view' method='post' action='addtocart.php'>
												<input type='submit' name='action' value='Add to Cart'/>
												<input type='hidden' name='addid' value='$id'/>
												</form>";
										
										echo '</div>';
									echo '</div>';
									
									
								}
								
							}
						}
						else if(isset($_POST['Bottoms']))
						{
							
							
							
							for( $id = 0; $id<1; $id++)
							{
							
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								$sql  = "SELECT * FROM clothes where `Type` = 'Bottoms'";
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									$image = $rows['Picture'];
									
									echo '<div id = "holderrows">';
										echo '<div id = "holder">';

											echo "<img src='$image' width= '200px' height='300px' >";
											echo "<p id='Desc'>".$rows['Description']."</p>";
									
											echo "<form id='view' method='post' action='addtocart.php'>
													<input type='submit' name='action' value='Add to Cart'/>
													<input type='hidden' name='addid' value='$id'/>
												</form>";
										
										echo '</div>';
									echo '</div>';
									
									
								}
								
							}
						}
						else if(isset($_POST['Tops']))
						{
							
							
							
							for( $id = 0; $id<1; $id++)
							{
							
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								$sql  = "SELECT * FROM clothes where `Type` = 'Top'";
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									$image = $rows['Picture'];
									
									echo '<div id = "holderrows">';
										echo '<div id = "holder">';

											echo "<img src='$image' width= '200px' height='300px' >";
											echo "<p id='Desc'>".$rows['Description']."</p>";
									
											echo "<form id='view' method='post' action='addtocart.php'>
													<input type='submit' name='action' value='Add to Cart'/>
													<input type='hidden' name='addid' value='$id'/>
												</form>";
										
										echo '</div>';
									echo '</div>';
									
									
								}
								
							}
						}
						else if(isset($_POST['Footwear']))
						{
							
							
							
							for( $id = 0; $id<1; $id++)
							{
							
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								$sql  = "SELECT * FROM clothes where `Type` = 'Footwear'";
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									$image = $rows['Picture'];
									
									echo '<div id = "holderrows">';
										echo '<div id = "holder">';

											echo "<img src='$image' width= '200px' height='300px' >";
											echo "<p id='Desc'>".$rows['Description']."</p>";
									
												echo "<form id='view' method='post' action='addtocart.php'>
													<input type='submit' name='action' value='Add to Cart'/>
													<input type='hidden' name='addid' value='$id'/>
												</form>";
										
										echo '</div>';
									echo '</div>';
									
									
								}
								
							}
						}
						else if(isset($_POST['Accessories']))
						{
							
							
							
							for( $id = 0; $id<1; $id++)
							{
							
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								$sql  = "SELECT * FROM clothes where `Type` = 'Accessories'";
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									$image = $rows['Picture'];
									
									echo '<div id = "holderrows">';
										echo '<div id = "holder">';

											echo "<img src='$image' width= '200px' height='300px' >";
											echo "<p id='Desc'>".$rows['Description']."</p>";
									
												echo "<form id='view' method='post' action='addtocart.php'>
													<input type='submit' name='action' value='Add to Cart'/>
													<input type='hidden' name='addid' value='$id'/>
												</form>";
												
										echo '</div>';
									echo '</div>';
									
									
								}
								
							}
						}
						else
						{
						
							for( $id = 0; $id<100; $id++)
							{
								
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								
								$sql  = "SELECT * FROM clothes where `ID` = $id";
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									$image = $rows['Picture'];
								
									echo '<div id = "holderrows">';
										echo '<div id = "holder">';
											echo '<div id = "itemimage">';
												echo "<img src='$image' width= '200px' height='300px' >";
												echo "<p id='Desc'>".$rows['Description']."</p>";
										
												echo "<form id='view' method='post' action='addtocart.php'>
													<input type='submit' name='action' value='Add to Cart'/>
													<input type='hidden' name='addid' value='$id'/>
												</form>";
											echo '</div>';
										
										echo '</div>';
									echo '</div>';

								}
								
								
								
							}
						}
						
						?>
						
			
			
					</div>
				</div>
			</div>
		</div>
	</body>
</html>