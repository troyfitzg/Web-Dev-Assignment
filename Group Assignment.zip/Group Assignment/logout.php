<?php
	session_start();
	session_destroy(); //Logs out user
	
	$con = mysqli_connect("localhost","root","","groupassignment");
	$delete = "Delete from cart";
	$run_delete = mysqli_query($con,$delete);
	header("Location:WebDAssign.php");
 ?>