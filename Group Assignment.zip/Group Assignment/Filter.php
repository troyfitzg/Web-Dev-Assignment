<?php 
	session_start();
	unset($_SESSION['Filter']);

	$con = mysqli_connect("localhost","root","","groupassignment");
	  
	$filter = "SELECT * FROM clothes where 'Type' = '". $_POST['type'] ."'";
	if(isset($_GET["filter"]) == 'Tops') 
		{
			header("Location:MainShop.php?filter=Tops");
			return;
		}
	else
	{
		print "wrong";
	}
?>
