<?php

	$id = $_POST['addid'];
	$con = mysqli_connect("localhost","root","","groupassignment"); 
	$sql  = "insert into cart (SELECT * FROM clothes where ID = '$id')"; 
	$result = mysqli_query($con,$sql);
			
			header("Location:MainShop.php");
			
?>
