<?php

	$remove = $_POST['remove'];
	$con = mysqli_connect("localhost","root","","groupassignment");
	$delete = "Delete from cart"; //Clears cart
	$run_delete = mysqli_query($con,$delete);
	
	header("Location:Cart.php");