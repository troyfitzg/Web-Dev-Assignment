
<html>
<link id = "css" rel="stylesheet" type="text/css" href="assign.css">
<body>

<div id = "whole">

	<div id = "main">

		<div id = "navbar">
			<ul>
				<li><div id = "logoimg"><img id = "logo" src= "images/assignlogo.png" height = "70px" width="80px" onclick="window.location.href = 'WebDAssign.php'" /></div></li>
				<li><input id="shopbutton" type="button" value="Shop" onclick="window.location.href = 'MainShop.php'" /></li>		
				<li><input id="cartbutton" type="button" value="Cart" onclick="window.location.href = 'Cart.php'" /></li>
				<li><input id="wishlistbutton" type="button" value="Wish List" onclick="window.location.href = 'WishList.php'" /></li>
				
				 <?php
				session_start();
				
				if (isset($_SESSION['username'])) {
				echo "<li><input id='loginbutton' type='button' value='Account' onclick='window.location.href =\"Account.php\"' /></li>";
				echo "<li><input id='loginbutton' type='button' value='Log Out' onclick='window.location.href =\"logout.php\"' /></li>";
				}
				else
				{
				?>	
				<li><input id="loginbutton" type="button" value="Login" onclick="window.location.href = 'Login.php'" /></li>
				<li><input id="registerbutton" type="button" value="Register" onclick="window.location.href = 'Register.php'" /></li>
			</ul>
				<?php }
				?>
		</div>
		
		
	
		

		<div id = "regform">
				<form action="changepword.php" method = "post">
				<br>
				<input type="password" name="newpassword" placeholder=" Enter New Password" required>
				<br>
				<br>
				<input type="password" name="newpassword2" placeholder=" Re-enter New Password" required>
				<br>
				<br>
				&nbsp&nbsp&nbsp
				
				<button id="changebutton">Change</button>

		</div>

<?php
	
	if(isset($_POST['newpassword'])) //Update your password
	{
		if( $_POST['newpassword'] == $_POST['newpassword2'])
		{
		
			$_SESSION['newpassword'] = $_POST['newpassword'];
			$password = $_SESSION['newpassword'];
			$current_user = $_SESSION['username'];
			$con = mysqli_connect("localhost","root","","groupassignment"); 
			$update = "Update reg_user SET `Password` = '$password' where Username = '$current_user'";
			$run_update = mysqli_query($con,$update);
			echo "<script>alert('Password Has been Updated')</script>";
			header("Location:Account.php");
			
		}
	}

?>



</body>
</html>