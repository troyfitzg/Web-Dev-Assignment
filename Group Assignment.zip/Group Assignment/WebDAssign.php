<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Group Assignment - Troy Fitzgerald (C16432792) & Khurram Farooq (C16364286) </title>
	<link id = "css" rel="stylesheet" type="text/css" href="assign.css">
	<style>
		<!--Slideshow CSS-->
		* {box-sizing: border-box}
		body {font-family: Verdana, sans-serif; margin:0}
		.mySlides {display: none}	
		img {vertical-align: middle;}

		/* Slideshow container */
		.slideshow-container {
		max-width: 100%;
		position: relative;
		margin: auto;
		}

		/* Next & previous buttons */
		.prev, .next {
		cursor: pointer;	
		position: absolute;
		top: 50%;
		width: auto;
		padding: 16px;
		margin-top: -22px;
		color: white;
		font-weight: bold;
		font-size: 18px;
		transition: 0.6s ease;
		border-radius: 0 3px 3px 0;
		user-select: none;
		}

		/* Position the "next button" to the right */
		.next {
		right: 0;
		border-radius: 3px 0 0 3px;
		}

		/* On hover, add a black background color with a little bit see-through */
		.prev:hover, .next:hover {
			background-color: rgba(0,0,0,0.8);
		}

		/* Caption text */
		.text {
		color: black;
		font-size: 15px;
		padding: 8px 12px;
		position: absolute;
		bottom: 8px;
		width: 100%;
		text-align: top-left;
		}

		/* Number text (1/6 etc) */
		.numbertext {
		color: black;
		font-size: 12px;
		padding: 8px 12px;
		position: absolute;
		top: 0;
		}

		/* The dots/bullets/indicators */
		.dot {
		cursor: pointer;
		height: 15px;
		width: 15px;
		margin: 0 2px;
		background-color: #bbb;
		border-radius: 50%;
		display: inline-block;
		transition: background-color 0.6s ease;
		}

		.active, .dot:hover {
		background-color: #717171;
		}

		/* Fading animation */
		.fade {
		-webkit-animation-name: fade;
		-webkit-animation-duration: 0s;
		animation-name: fade;
		animation-duration: 2s;
		}

		@-webkit-keyframes fade {
		from {opacity: .4} 
		to {opacity: 1}
		}

		@keyframes fade {
		from {opacity: .4} 
		to {opacity: 1}
		}

		/* On smaller screens, decrease text size */
		@media only screen and (max-width: 300px) {
		.prev, .next,.text {font-size: 11px}
		}
		<!--END Slideshow CSS-->
		
		<!--Card CSS-->
		.card {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
		max-width: 300px;
		margin: auto;
		text-align: center;
		font-family: arial;
		}

		.price {
		color: grey;
		font-size: 22px;
		}

		.card button {
		border: none;
		outline: 0;
		padding: 12px;
		color: white;
		background-color: #000;
		text-align: center;
		cursor: pointer;
		width: 100%;
		font-size: 18px;
		}

		.card button:hover {
		opacity: 0.7;
		}

		h1{
		postion: absolute;
		float: right;
		}
		<!--END Card CSS-->
	</style>
</head>

<script type="text/javascript"></script>

<div id = "whole">
	<div id = "main">
		<div id = "navbar">
			<ul>
				<li><div id = "logoimg"><img id = "logo" src= "images/assignlogo.png" height = "70px" width="80px" onclick="window.location.href = 'WebDAssign.php'" /></div></li>
				<li><input id="shopbutton" type="button" value="Shop" onclick="window.location.href = 'MainShop.php'" /></li>		
				<li><input id="cartbutton" type="button" value="Cart" onclick="window.location.href = 'Cart.php'" /></li>
				<li><input id="wishlistbutton" type="button" value="Wish List" onclick="window.location.href = 'WishList.php'" /></li>
				<li><input id="loginbutton" type="button" value="Login" onclick="window.location.href = 'Login.php'" /></li>
				<li><input id="registerbutton" type="button" value="Register" onclick="window.location.href = 'Register.php'" /></li>
			</ul>
		</div>
		
		<div class="slideshow-container">

			<div class="mySlides fade">
				<div class="numbertext">COLORFUL SHIRTS: BRAND NEW!</div>
					<img src="images/tshirtbanner.jpg" style="width:100%">
				<div class="text"></div>
			</div>

			<div class="mySlides fade">
				<div class="numbertext">DESIGNER SHIRTS: MOST POPULAR!</div>
					<img src="images/tshirt2banner.jpg" style="width:100%">
				<div class="text"></div>
			</div>

			<div class="mySlides fade">
				<div class="numbertext">SHOES: FOR ALL OCCASIONS!</div>
					<img src="images/shoesbanner.jpg" style="width:100%">
				<div class="text"></div>
			</div>

			<div class="mySlides fade">
				<div class="numbertext">RUNNERS: FOR ALL OCCASIONS!</div>
					<img src="images/shoes2banner.jpg" style="width:100%">
				<div class="text"></div>
			</div>

			<div class="mySlides fade">
				<div class="numbertext">CASUAL JEANS</div>
					<img src="images/jeans2.jpg" style="width:100%">
				<div class="text">RANGE OF DESIGNS</div>
			</div>

			<div class="mySlides fade">
				<div class="numbertext">SKINNY JEANS</div>
					<img src="images/jeans3banner.jpg" style="width:100%">
				<div class="text">SKINNY TO SUPER SKINNY</div>
			</div>

			<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
			<a class="next" onclick="plusSlides(1)">&#10095;</a>	
		</div>
		<br></br>
	
		<script>
			var slideIndex = 1;
			showSlides(slideIndex);

			function plusSlides(n) {
				showSlides(slideIndex += n);
			}

			function currentSlide(n) {
				showSlides(slideIndex = n);
			}

			function showSlides(n) {
				var i;
				var slides = document.getElementsByClassName("mySlides");
				var dots = document.getElementsByClassName("dot");
					if (n > slides.length) {slideIndex = 1}    
						if (n < 1) {slideIndex = slides.length}
							for (i = 0; i < slides.length; i++) {
								slides[i].style.display = "none";  
								}
							for (i = 0; i < dots.length; i++) {
								dots[i].className = dots[i].className.replace(" active", "");
								}
				slides[slideIndex-1].style.display = "block";  
				dots[slideIndex-1].className += " active";
			}
		</script>
		<br></br>
		<h2 style="text-align:center">MOST POPULAR</h2>
		<br></br>
		<div class="card">
			<a href="MainShop.php"><img src="images/item2.jpg" alt="Denim Jeans" style="width:25%"></a>
			<a href="MainShop.php"><img src="images/item7.jpg" alt="Skinny Jeans" style="width:25%"></a>
				<h1>Denim Jeans</h1>
				<p class="price"> Starting @€29.99</p>
				<p>Casual bottoms that come in different colours & shades.</p>
		</div>
		
		<h2 style="text-align:center">NEW COLLECTION</h2>
		<br></br>
		<div class="card">
			<a href="MainShop.php"><img src="images/item3.jpg" alt="Shoes & Runners" style="width:25%"></a>
			<a href="MainShop.php"><img src="images/item10.jpg" alt="Shoes & Runners" style="width:25%"></a>
				<h1>Shoes/Runners</h1>
				<p class="price"> Starting @€19.99</p>
				<p>Runners in different and unique styles.</p>
		</div>
		
		<h2 style="text-align:center">JUST IN</h2>
		<br></br>
		<div class="card">
			<a href="MainShop.php"><img src="images/item1.jpg" alt="Tops" style="width:25%"></a>
			<a href="MainShop.php"><img src="images/item5.jpg" alt="Tops" style="width:25%"></a>
			<!--<a href="MainShop.php"><img src="images/item9.jpg" alt="Tops" style="width:25%"></a>-->
				<h1>Tops</h1>
				<p class="price"> Starting @€14.99</p>
				<p>Casual tops as well as designer tops in different and unique styles.</p>
		</div>
		
		<h2 style="text-align:center">MUST HAVE</h2>
		<br></br>
		<div class="card">
			<a href="MainShop.php"><img src="images/item8.jpg" alt="Accessories" style="width:25%" ></a>
			<a href="MainShop.php"><img src="images/item4.jpg" alt="Accessories" style="width:25%"></a>	
				<h1>Accessories</h1>
				<p class="price"> Starting @€4.99</p>
				<p>Stylish caps & neckalaces.</p>
		</div><!--END DIV CARD-->
	</div><!--END MAIN-->
</div><!--END WHOLE-->
</body>
</html>