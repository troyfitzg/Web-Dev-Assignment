-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2018 at 01:32 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groupassignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `ID` int(20) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Price` float NOT NULL,
  `Picture` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`ID`, `Brand`, `Description`, `Type`, `Price`, `Picture`) VALUES
(2, 'Diesel', 'Bluebell Dad Jean', 'Bottoms', 54, 'images/item2.jpg'),
(7, 'Tommy Hilfigure', 'Crest Sweatpants', 'Bottoms', 65, 'images/item7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `clothes`
--

CREATE TABLE `clothes` (
  `ID` int(20) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Price` float NOT NULL,
  `Picture` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clothes`
--

INSERT INTO `clothes` (`ID`, `Brand`, `Description`, `Type`, `Price`, `Picture`) VALUES
(1, 'Adidas', 'NMD Ivory Teddy Hoodie', 'Top', 90, 'images/item1.jpg'),
(2, 'Diesel', 'Bluebell Dad Jean', 'Bottoms', 54, 'images/item2.jpg'),
(3, 'Nike', 'Air Force 1', 'Footwear', 110, 'images/item3.jpg'),
(4, 'Dickies', 'Willow City Yellow Cap', 'Accessories', 30, 'images/item4.jpg'),
(5, 'Champion', 'Neon Stacked Hoodie Sweatshirt', 'Top', 100, 'images/item5.jpg'),
(6, 'Vans', 'Old Skool', 'Footwear', 100, 'images/item6.jpg'),
(7, 'Tommy Hilfigure', 'Crest Sweatpants', 'Bottoms', 65, 'images/item7.jpg'),
(8, 'Champion', 'Heritage CZ Necklace', 'Accessories', 90, 'images/item8.jpg'),
(9, 'Fila', 'Tonetto Colorblock Sherpa Jacket', 'Top', 85, 'images/item9.jpg'),
(10, 'Adidas', 'Deerupt Runner', 'Footwear', 75, 'images/item10.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reg_user`
--

CREATE TABLE `reg_user` (
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Profile_Picture` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_user`
--

INSERT INTO `reg_user` (`Email`, `Password`, `Username`, `FirstName`, `LastName`, `Profile_Picture`) VALUES
('troyfitzg@hotmail.com', '12345', 'TroyFitzG', 'Troy', 'Fitzgerald', '');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `ID` int(20) NOT NULL,
  `Description` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Stock` int(20) NOT NULL,
  `Reorder_Level` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wish_list`
--

CREATE TABLE `wish_list` (
  `ID` int(20) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clothes`
--
ALTER TABLE `clothes`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reg_user`
--
ALTER TABLE `reg_user`
  ADD PRIMARY KEY (`Email`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clothes`
--
ALTER TABLE `clothes`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
