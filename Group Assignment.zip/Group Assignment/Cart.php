<html>
<head>

	<title> Group Assignment - Troy Fitzgerald (C16432792) & Khurram Farooq (C16364286) </title>
	
	<link id = "css" rel="stylesheet" type="text/css" href="assign.css">
	
</head>



<script type ="text/javascript">






</script>

<div id = "whole">

	<div id = "main">
		<div id = "navbar">
			<ul>
				<li><div id = "logoimg"><img id = "logo" src= "images/assignlogo.png" height = "70px" width="80px" onclick="window.location.href = 'WebDAssign.php'" /></div></li>
				<li><input id="shopbutton" type="button" value="Shop" onclick="window.location.href = 'MainShop.php'" /></li>		
				<li><input id="cartbutton" type="button" value="Cart" onclick="window.location.href = 'Cart.php'" /></li>
				<li><input id="wishlistbutton" type="button" value="Wish List" onclick="window.location.href = 'WishList.php'" /></li>
				
				 <?php
				session_start();
				
				if (isset($_SESSION['username'])) {
				echo "<li><input id='loginbutton' type='button' value='Account' onclick='window.location.href =\"Account.php\"' /></li>";
				echo "<li><input id='loginbutton' type='button' value='Log Out' onclick='window.location.href =\"logout.php\"' /></li>";
				}
				else
				{
				?>	
				<li><input id="loginbutton" type="button" value="Login" onclick="window.location.href = 'Login.php'" /></li>
				<li><input id="registerbutton" type="button" value="Register" onclick="window.location.href = 'Register.php'" /></li>
			</ul>
				<?php }
				?>
		</div>
	
		<div id = "cart display">
			<?php
			if (isset($_SESSION['username'])) { 
				
				for( $id = 0; $id<1; $id++)
					{
							
								$con = mysqli_connect("localhost","root","","groupassignment"); 
								$sql  = "SELECT * FROM cart";
								$total = "SELECT SUM(Price) as Total from cart";
								 
						
								
								$result = mysqli_query($con,$sql);

								while($rows=mysqli_fetch_assoc($result))
								{
									
								
									echo "<p id='Desc2'>".$rows['Description']."            $".$rows['Price']."</p>";
			
								}
								
									echo "<form id='view' method='post' action='deletefromcart.php'>
										<br>
										<br>
										<input type='submit' name='action' value='Empty Cart'/>
										<input type='hidden' name='remove' value='$id'/>
										</form>";
								
					
								
								
					}
			?>
			&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
			<input id="regbutton" type="button" value="Checkout" onclick="window.location.href = 'logout.php'" /></li>
			<br>
			<br>
			
			
			<?php
			}
			else
			{
				echo "<p id = 'carterr'> You must be <a id = 'signin'href = 'Login.php'> Signed in </a> to view Cart</p>";
			}
?>
</div>
