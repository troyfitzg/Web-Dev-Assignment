<html>
<head>

	<title> Group Assignment - Troy Fitzgerald (C16432792) & Khurram Farooq (C16364286) </title>
	
	<link id = "css" rel="stylesheet" type="text/css" href="assign.css">
	
</head>



<script type ="text/javascript">






</script>

<div id = "whole">

	<div id = "main">

			<div id = "navbar">
			<ul>
				<li><div id = "logoimg"><img id = "logo" src= "images/assignlogo.png" height = "70px" width="80px" onclick="window.location.href = 'WebDAssign.php'" /></div></li>
				<li><input id="shopbutton" type="button" value="Shop" onclick="window.location.href = 'MainShop.php'" /></li>		
				<li><input id="cartbutton" type="button" value="Cart" onclick="window.location.href = 'Cart.php'" /></li>
				<li><input id="wishlistbutton" type="button" value="Wish List" onclick="window.location.href = 'WishList.php'" /></li>
				
				 <?php
				session_start();
				
				if (isset($_SESSION['username'])) {
				echo "<li><input id='loginbutton' type='button' value='Account' onclick='window.location.href =\"Account.php\"' /></li>";
				echo "<li><input id='loginbutton' type='button' value='Log Out' onclick='window.location.href =\"logout.php\"' /></li>";
				}
				else
				{
				?>	
				<li><input id="loginbutton" type="button" value="Login" onclick="window.location.href = 'Login.php'" /></li>
				<li><input id="registerbutton" type="button" value="Register" onclick="window.location.href = 'Register.php'" /></li>
			</ul>
				<?php }
				?>
		</div>
		
		<?php
		
		if(isset($_SESSION['username']))
		{
		}
		else
			{
				echo "<p id = 'carterr'> You must be <a id = 'signin'href = 'Login.php'> Signed in </a> to view your Wish List</p>";
			}