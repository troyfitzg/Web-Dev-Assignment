<?php
	
	session_start();
	
	$current_user = $_SESSION['username'];
	$con = mysqli_connect("localhost","root","","groupassignment");
	$delete = "Delete from reg_user where `Username` = '$current_user'"; //removes account from database
	$run_delete = mysqli_query($con,$delete);
	
	header("Location:WebDAssign.php");
	
	session_destroy();
	
?>
	
	