<?php 
session_start();
 $con = mysqli_connect("localhost","root","","groupassignment");
 
 $query = "SELECT * FROM reg_user WHERE Username='".$_POST['username']."' AND Password='".$_POST['password']."'";

 $sql = $con->query($query);
 
 $n = $sql->num_rows;
  
 if($n > 0){
 
	header("Location:WebDAssign.php");
	
	$_SESSION['username']= $_POST['username']; 	
 }
 else
 {
	
	header("Location:Login.php?msg=failed");
	return;
	 
	 
	 
 }

?>