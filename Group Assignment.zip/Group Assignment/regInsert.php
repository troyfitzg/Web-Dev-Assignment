<?php

$con=mysqli_connect("localhost","root","","groupassignment");


$sql="INSERT INTO reg_user (Email, Password , Username , FirstName , LastName)
VALUES
('$_POST[email]','$_POST[password]','$_POST[username]','$_POST[fname]','$_POST[lname]')";

if(!mysqli_query($con,$sql))
{
	die('Error: ' . mysqli_error());
}

mysqli_close($con);

header("Location:MainShop.php");

?>