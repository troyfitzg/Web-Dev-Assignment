<html>
<head>

	<title> Group Assignment - Troy Fitzgerald (C16432792) & Khurram Farooq (C16364286) </title>
	
	<link id = "css" rel="stylesheet" type="text/css" href="assign.css">
	
</head>

<div id = "whole">

	<div id = "main">
		<div id = "navbar">
			<ul>
				<li><div id = "logoimg"><img id = "logo" src= "images/assignlogo.png" height = "70px" width="80px" onclick="window.location.href = 'WebDAssign.php'" /></div></li>
				<li><input id="shopbutton" type="button" value="Shop" onclick="window.location.href = 'MainShop.php'" /></li>		
				<li><input id="cartbutton" type="button" value="Cart" onclick="window.location.href = 'Cart.php'" /></li>
				<li><input id="wishlistbutton" type="button" value="Wish List" onclick="window.location.href = 'WishList.php'" /></li>
				
				 <?php
				session_start();
				
				if (isset($_SESSION['username'])) {
				echo "<li><input id='loginbutton' type='button' value='Account' onclick='window.location.href =\"Account.php\"' /></li>";
				echo "<li><input id='loginbutton' type='button' value='Log Out' onclick='window.location.href =\"logout.php\"' /></li>";
				}
				else
				{
				?>	
				<li><input id="loginbutton" type="button" value="Login" onclick="window.location.href = 'Login.php'" /></li>
				<li><input id="registerbutton" type="button" value="Register" onclick="window.location.href = 'Register.php'" /></li>
			</ul>
				<?php }
				?>
		</div>
		
		
		
		<div id = "logform">

		<form action="loginCheck.php" method = "post">
		<br>
        <input type="text" id = "username" name="username" placeholder=" Username" required>
        <br>
		<br>
		<br>
        <input type="password" id = "password" name="password" placeholder=" Password" required>
		<br>
		<br>	
		<br>
		&nbsp&nbsp&nbsp
		<input type="submit" id="logbutton" value = "Login">
		<br>
		<br>
        </form>
		</div>
		
		
		<div id = "wronginfo">
			<?php if(isset($_GET["msg"]) && $_GET["msg"] == 'failed') 
			{
				echo "Wrong Username / Password";
			}
			 ?>
		</div>
		
	</div>
	
</div>